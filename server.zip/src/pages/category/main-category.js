import React from 'react'
 const MainCategoryList= () => {
  return (
    <div>main-category</div>
  )
}


export default MainCategoryList